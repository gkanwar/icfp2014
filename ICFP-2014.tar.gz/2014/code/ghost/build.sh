#!/bin/bash

./a.out < tracker.ghc > temp.ghc
cat temp.ghc
